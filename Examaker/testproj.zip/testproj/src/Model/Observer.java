package Model;

public interface Observer {

	void update();

}
