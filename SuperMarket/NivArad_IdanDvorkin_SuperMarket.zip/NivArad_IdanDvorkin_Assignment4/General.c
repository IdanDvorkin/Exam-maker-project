#define  _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <ctype.h>
#include "General.h"



char* getStrExactLength(const char* msg)
{
	char* str;
	char temp[MAX_STR_LEN];
	getsStrFixSize(temp, MAX_STR_LEN, msg);

	str = getDynStr(temp);
	return str;
}

char* getDynStr(char* str)
{
	char* theStr;
	theStr = (char*)malloc((strlen(str) + 1) * sizeof(char));
	if (!theStr)
		return NULL;

	strcpy(theStr, str);
	return theStr;
}

char*	getsStrFixSize(char* buffer, int size, const char* msg)
{
	puts(msg);
	return myGets(buffer, size,stdin);
}

char*  myGets(char* buffer, int size, FILE* source)
{
	if (buffer != NULL && size > 0)
	{
		if (fgets(buffer, size, source))
		{
			buffer[strcspn(buffer, "\n")] = '\0';
			return buffer;
		}
		buffer[0] = '\0';
	}
	return NULL;
}

char**	splitCharsToWords(char* str, int* pCount, const char* del, int* pTotalLength)
{
	char* word;
	int count = 0;
	char* temp = _strdup(str);
	*pTotalLength = 0;
	char** wordsArray = NULL;

	word = strtok(temp, del);
	while (word != NULL)
	{
		int res = 0;
		char** temp = NULL;
		temp= (char**)realloc(wordsArray, (count + 1) * sizeof(char*));
		if (!temp)
			return 0;
		wordsArray = temp;
		if (!wordsArray)
			return 0;
		wordsArray[count] = getDynStr(word);
		count++;
		*pTotalLength += (int)strlen(word);
		word = strtok(NULL, del);
	}
	*pCount = count;
	free(temp);
	return wordsArray;
}


float	getPositiveFloat(const char* msg)
{
	int garbage = 0;
	float val;
	do {
		puts(msg);
		garbage=scanf("%f", &val);
	} while (val < 0);
	return val;
}

int		getPositiveInt(const char* msg)
{
	int garbage = 0;
	int val;
	do {
		puts(msg);
		garbage=scanf("%d", &val);
	} while (val < 0);
	return val;
}

int		countCharInString(const char* str, char tav)
{
	int count = 0;
	while (*str)
	{
		if (*str == tav)
			count++;
		str++;
	}
	return count;
}

void generalArrayFunction(void* arr, int size, int typeSize, void(*func)(void* element))
{
	for (int i = 0; i < size; i++)
		func((char*)(arr)+i * typeSize);

}

int		checkEmptyString(char* str)
{
	while (*str)
	{
		if (!isspace(*str))
			return 0;
		str++;
	}
	return 1;
}
void decipherBarcode(char* c)
{
	if (*c < 10) {
		*c = *c + 48;
	}
	else {
		*c = *c + 55;
	}
}
void cipherBarcode(char* c)
{
	if (*c > 64) {
		*c = *c - 55;
	}
	else {
		*c = *c - 48;
	}
}
void printMessage(const char* str, ...)
{
	va_list statements;
	va_start(statements, str);
	char* currWord = (char*)str;
	while (currWord != NULL) {
		printf("%s ", currWord);
		currWord = va_arg(statements, char*);
	}

}
